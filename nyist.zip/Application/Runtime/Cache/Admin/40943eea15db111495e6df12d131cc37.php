<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link rel="stylesheet" type="text/css" href="<?php echo (ADMIN_CSS_URL); ?>main.css">
<link rel="stylesheet" type="text/css" href="<?php echo (ADMIN_CSS_URL); ?>general.css">

</head>

<body>
<h1>
<span class="action-span1"><a href="">管理中心</a> </span><span id="search_id" class="action-span1">---南工简介</span>
<div style="clear:both"></div>
</h1>
<h1 align="center" style="font-family:'华文彩云',黑体; font-size:36px; color:#000; font-size:36px;">南工简介</h1>
<p style="font-size:18px">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;南工电脑网社团成立于2004年4月.2006年被授予南阳理工委员会优秀社团称号. 2011年在移动教研室的大力支持下开创首个学生主导的开放实验室15#210.2014年移动教研室增加了云计算方向,在这个云计算大数据并行成为IT行业的巨头的时代,我们社团紧跟时代的步伐,致力于云计算的学习与研究中.社团2010年时,进行了一次改革,把社团内不学习,不做项目的人剔除.同年嵌入式映入大家眼帘,在指导的带领下,社团开始进行嵌入式方向的研究与开发,一直到现在有六年的时间了,社团历史悠久,经验丰富,走出了很多大神.
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;南工电脑网社团拥有12多年历史.从建团开始,社团从事网站维护,渐渐的社团开始壮大.在3年艰难建团时间后,2007年社团开始从事网站开发方向,后来社团可谓百花齐放.成员开始从事PS、PHP、动画制作等其他方向.2014年软件学院开始招收云计算技术应用方向的学生.14级的新生里边云计算一共4个班归属于移动教研室,而原来的移动方向就只剩下了一个班.我们社团在招生的时候开始招收云计算方向的成员,包括15级的成员大部分也是云计算方向的.在这个云技术大数据并行成为IT行业的巨头的时代,我们社团也不得不紧跟时代的步伐.所以以后社团分成两大方向：移动和云计算.移动方向我们社团已经搞了6年,往届的学长学姐们学的有：嵌入式、Android、IOS等,已经有了很丰富的经验,可以带领走这一方向的学弟学妹们走的更远.云计算方向有Hadoop、Openstack、Hbase、虚拟化技术等.当然社团成员也可以搞他们感兴趣的东西,例如：PHP、C++、HTML5、UI、PS等多元化发展.</p>

<div id="footer">
版权所有 &copy; - 南工社团 - 
</div>
</body>
</html>
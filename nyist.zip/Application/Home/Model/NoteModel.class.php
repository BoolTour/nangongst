<?php
namespace Home\Model;
use Model;

class NoteModel extends BaseModel{
	
}
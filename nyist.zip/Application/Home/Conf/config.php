<?php
return array(
	'TMPL_LAYOUT_ITEM'=>'{__CONTENT__}',   //内容
    'LAYOUT_ON'=>'true',      //启用布局
    'LAYOUT_NAME'=>'layout', //默认的布局名为layout
);
<script type="text/javascript" charset="utf-8" src="__PUBLIC__/ueditor/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="__PUBLIC__/ueditor/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="__PUBLIC__/ueditor/lang/zh-cn/zh-cn.js"></script>

UE.getEditor('sub_goods_name', {
	"initialFrameWidth" : "100%",
	"initialFrameHeight" : 80,
	"maximumWords" : 150,
	"toolbars" : btn_basic
});
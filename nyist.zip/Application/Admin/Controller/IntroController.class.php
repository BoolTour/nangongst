<?php
namespace Admin\Controller;
use Tool\AdminController;

class IntroController extends AdminController{
	public function lst(){
		$this->display();
	}
}
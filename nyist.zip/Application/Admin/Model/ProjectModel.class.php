<?php
namespace Admin\Model;
use Model;

class ProjectModel extends BaseModel{
	
}
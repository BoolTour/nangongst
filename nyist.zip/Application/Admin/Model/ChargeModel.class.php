<?php
namespace Admin\Model;
use Model;

class ChargeModel extends BaseModel{

}
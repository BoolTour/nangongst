<?php
namespace Admin\Model;
use Model;

class RankModel extends BaseModel{

}
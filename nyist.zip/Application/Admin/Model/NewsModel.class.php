<?php
namespace Admin\Model;
use Model;

class NewsModel extends BaseModel{

}
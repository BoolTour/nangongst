<?php
namespace Admin\Model;
use Model;

class LinkModel extends BaseModel{

}
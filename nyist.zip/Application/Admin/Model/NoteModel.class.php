<?php
namespace Admin\Model;
use Model;

class NoteModel extends BaseModel{

}